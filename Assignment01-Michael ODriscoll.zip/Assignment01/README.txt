Welcome to the MC Escher art page, which shows a generic home page to describe the website
Other pages include famous works, exhibitions etc.
There is a scroll box in Famous works which you need to be aware of, you can scroll from left to right
to view the whole image.
Other inclusions are the Embedded google maps for where the exhibition is located.
View videos in the videos section.
The rest is fairly simple to follow.

Images, google maps and scroll box use references below:

https://www.reddit.com/r/printmaking/comments/3w5mml/mc_escher_metamorphosis_ii_1940/
https://thechive.com/2020/07/18/mc-escher-gifs-will-fck-with-your-head/
https://www.goodreads.com/author/quotes/306401.M_C_Escher
https://color.adobe.com/create/image
https://www.amazon.co.uk/s?k=mc+esher+books&ref=nb_sb_noss
https://www.kennys.ie/childrens-teens/the-magic-mirror-of-mc-escher
https://imgur.com/gallery/ZLU0OBS/comment/253518730
https://www.williamquincybelle.com/2017/05/relativity-by-m-c-escher.html
https://www.pinterest.ie/pin/69454019227325400/
https://www.quackit.com/html/codes/html_scroll_box.cfm
https://www.w3schools.com/html/html_links_colors.asp
https://learnodo-newtonic.com/m-c-escher-facts
https://hashthemes.com/articles/add-google-map-with-iframe-embed-code/